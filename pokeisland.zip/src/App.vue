<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <div class="!bg-[#1E1E1E] w-full">
    
      <RouterView />
    </div>
</template>
